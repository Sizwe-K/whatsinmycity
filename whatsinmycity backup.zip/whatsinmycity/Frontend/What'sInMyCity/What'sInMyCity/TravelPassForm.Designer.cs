﻿namespace What_sInMyCity
{
    partial class TravelPassForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpPassDetails = new System.Windows.Forms.GroupBox();
            this.lblPassStatus = new System.Windows.Forms.Label();
            this.lblValidUntil = new System.Windows.Forms.Label();
            this.lblHolderName = new System.Windows.Forms.Label();
            this.lblPassType = new System.Windows.Forms.Label();
            this.lblPassID = new System.Windows.Forms.Label();
            this.lblPassIdD = new System.Windows.Forms.Label();
            this.lblPassTypeD = new System.Windows.Forms.Label();
            this.lblPassHolderN = new System.Windows.Forms.Label();
            this.lblPassValidD = new System.Windows.Forms.Label();
            this.lblPassStatusD = new System.Windows.Forms.Label();
            this.picQRCode = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnBackToMain = new System.Windows.Forms.Button();
            this.grpPassDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picQRCode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // grpPassDetails
            // 
            this.grpPassDetails.Controls.Add(this.btnBackToMain);
            this.grpPassDetails.Controls.Add(this.lblPassStatusD);
            this.grpPassDetails.Controls.Add(this.lblPassValidD);
            this.grpPassDetails.Controls.Add(this.lblPassHolderN);
            this.grpPassDetails.Controls.Add(this.lblPassTypeD);
            this.grpPassDetails.Controls.Add(this.lblPassIdD);
            this.grpPassDetails.Controls.Add(this.picQRCode);
            this.grpPassDetails.Controls.Add(this.lblPassStatus);
            this.grpPassDetails.Controls.Add(this.lblValidUntil);
            this.grpPassDetails.Controls.Add(this.lblHolderName);
            this.grpPassDetails.Controls.Add(this.lblPassType);
            this.grpPassDetails.Controls.Add(this.lblPassID);
            this.grpPassDetails.Location = new System.Drawing.Point(435, 169);
            this.grpPassDetails.Name = "grpPassDetails";
            this.grpPassDetails.Size = new System.Drawing.Size(988, 654);
            this.grpPassDetails.TabIndex = 2;
            this.grpPassDetails.TabStop = false;
            this.grpPassDetails.Text = "Travel Pass Details";
            // 
            // lblPassStatus
            // 
            this.lblPassStatus.AutoSize = true;
            this.lblPassStatus.Location = new System.Drawing.Point(28, 232);
            this.lblPassStatus.Name = "lblPassStatus";
            this.lblPassStatus.Size = new System.Drawing.Size(81, 16);
            this.lblPassStatus.TabIndex = 4;
            this.lblPassStatus.Text = "Pass Status:";
            // 
            // lblValidUntil
            // 
            this.lblValidUntil.AutoSize = true;
            this.lblValidUntil.Location = new System.Drawing.Point(28, 188);
            this.lblValidUntil.Name = "lblValidUntil";
            this.lblValidUntil.Size = new System.Drawing.Size(70, 16);
            this.lblValidUntil.TabIndex = 3;
            this.lblValidUntil.Text = "Valid Until:";
            // 
            // lblHolderName
            // 
            this.lblHolderName.AutoSize = true;
            this.lblHolderName.Location = new System.Drawing.Point(28, 145);
            this.lblHolderName.Name = "lblHolderName";
            this.lblHolderName.Size = new System.Drawing.Size(91, 16);
            this.lblHolderName.TabIndex = 2;
            this.lblHolderName.Text = "Holder Name:";
            // 
            // lblPassType
            // 
            this.lblPassType.AutoSize = true;
            this.lblPassType.Location = new System.Drawing.Point(28, 101);
            this.lblPassType.Name = "lblPassType";
            this.lblPassType.Size = new System.Drawing.Size(76, 16);
            this.lblPassType.TabIndex = 1;
            this.lblPassType.Text = "Pass Type:";
            // 
            // lblPassID
            // 
            this.lblPassID.AutoSize = true;
            this.lblPassID.Location = new System.Drawing.Point(28, 46);
            this.lblPassID.Name = "lblPassID";
            this.lblPassID.Size = new System.Drawing.Size(57, 16);
            this.lblPassID.TabIndex = 0;
            this.lblPassID.Text = "Pass ID:";
            // 
            // lblPassIdD
            // 
            this.lblPassIdD.AutoSize = true;
            this.lblPassIdD.Location = new System.Drawing.Point(170, 50);
            this.lblPassIdD.Name = "lblPassIdD";
            this.lblPassIdD.Size = new System.Drawing.Size(63, 16);
            this.lblPassIdD.TabIndex = 8;
            this.lblPassIdD.Text = "lblPassId";
            // 
            // lblPassTypeD
            // 
            this.lblPassTypeD.AutoSize = true;
            this.lblPassTypeD.Location = new System.Drawing.Point(170, 101);
            this.lblPassTypeD.Name = "lblPassTypeD";
            this.lblPassTypeD.Size = new System.Drawing.Size(63, 16);
            this.lblPassTypeD.TabIndex = 9;
            this.lblPassTypeD.Text = "lblPassId";
            // 
            // lblPassHolderN
            // 
            this.lblPassHolderN.AutoSize = true;
            this.lblPassHolderN.Location = new System.Drawing.Point(170, 145);
            this.lblPassHolderN.Name = "lblPassHolderN";
            this.lblPassHolderN.Size = new System.Drawing.Size(63, 16);
            this.lblPassHolderN.TabIndex = 10;
            this.lblPassHolderN.Text = "lblPassId";
            // 
            // lblPassValidD
            // 
            this.lblPassValidD.AutoSize = true;
            this.lblPassValidD.Location = new System.Drawing.Point(170, 188);
            this.lblPassValidD.Name = "lblPassValidD";
            this.lblPassValidD.Size = new System.Drawing.Size(63, 16);
            this.lblPassValidD.TabIndex = 11;
            this.lblPassValidD.Text = "lblPassId";
            // 
            // lblPassStatusD
            // 
            this.lblPassStatusD.AutoSize = true;
            this.lblPassStatusD.Location = new System.Drawing.Point(170, 232);
            this.lblPassStatusD.Name = "lblPassStatusD";
            this.lblPassStatusD.Size = new System.Drawing.Size(63, 16);
            this.lblPassStatusD.TabIndex = 12;
            this.lblPassStatusD.Text = "lblPassId";
            // 
            // picQRCode
            // 
            this.picQRCode.Image = global::What_sInMyCity.Properties.Resources.randomqr_256;
            this.picQRCode.Location = new System.Drawing.Point(512, 21);
            this.picQRCode.Name = "picQRCode";
            this.picQRCode.Size = new System.Drawing.Size(441, 327);
            this.picQRCode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picQRCode.TabIndex = 5;
            this.picQRCode.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.OliveDrab;
            this.pictureBox1.Image = global::What_sInMyCity.Properties.Resources.Untitled;
            this.pictureBox1.Location = new System.Drawing.Point(594, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(678, 140);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // btnBackToMain
            // 
            this.btnBackToMain.Location = new System.Drawing.Point(698, 559);
            this.btnBackToMain.Name = "btnBackToMain";
            this.btnBackToMain.Size = new System.Drawing.Size(255, 49);
            this.btnBackToMain.TabIndex = 13;
            this.btnBackToMain.Text = "Back to Main Menu";
            this.btnBackToMain.UseVisualStyleBackColor = true;
            // 
            // TravelPassForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OliveDrab;
            this.ClientSize = new System.Drawing.Size(1801, 815);
            this.Controls.Add(this.grpPassDetails);
            this.Controls.Add(this.pictureBox1);
            this.Name = "TravelPassForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TravelPassForm";
            this.Load += new System.EventHandler(this.TravelPassForm_Load);
            this.grpPassDetails.ResumeLayout(false);
            this.grpPassDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picQRCode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox grpPassDetails;
        private System.Windows.Forms.Label lblValidUntil;
        private System.Windows.Forms.Label lblHolderName;
        private System.Windows.Forms.Label lblPassType;
        private System.Windows.Forms.Label lblPassID;
        private System.Windows.Forms.PictureBox picQRCode;
        private System.Windows.Forms.Label lblPassStatus;
        private System.Windows.Forms.Label lblPassIdD;
        private System.Windows.Forms.Label lblPassStatusD;
        private System.Windows.Forms.Label lblPassValidD;
        private System.Windows.Forms.Label lblPassHolderN;
        private System.Windows.Forms.Label lblPassTypeD;
        private System.Windows.Forms.Button btnBackToMain;
    }
}