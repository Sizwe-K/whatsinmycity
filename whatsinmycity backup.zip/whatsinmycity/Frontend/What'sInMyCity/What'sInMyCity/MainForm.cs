﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace What_sInMyCity
{
    public partial class MainForm : Form
    {
        public string conn = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=whatsinmycity;Integrated Security=True;TrustServerCertificate=True";
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnNavAttractions_Click(object sender, EventArgs e)
        {
            AttractionsForm attractions = new AttractionsForm();
            attractions.ShowDialog();
        }

        private void btnNavProfile_Click(object sender, EventArgs e)
        {
            UserProfileForm Profile = new UserProfileForm();
            Profile.ShowDialog();
        }

        private void btnNavBookings_Click(object sender, EventArgs e)
        {
            BookingForm Booking = new BookingForm();
            Booking.ShowDialog();
        }

        private void btnNavPasses_Click(object sender, EventArgs e)
        {
            TravelPassForm travelpass = new TravelPassForm();
            travelpass.ShowDialog();
        }

        private void btnNavIDScan_Click(object sender, EventArgs e)
        {

        }

        private void btnNavReports_Click(object sender, EventArgs e)
        {
            AdminReportsForm adminreports = new AdminReportsForm();
            adminreports.ShowDialog();
        }

        private void lblWelcome_Click(object sender, EventArgs e)
        {

        }

        private void btnNavLogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
