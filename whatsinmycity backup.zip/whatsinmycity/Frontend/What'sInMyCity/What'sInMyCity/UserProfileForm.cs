﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace What_sInMyCity
{
    public partial class UserProfileForm : Form
    {
        public int userID = 1;
        public string conn = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=whatsinmycity;Integrated Security=True;TrustServerCertificate=True";
        public UserProfileForm()
        {
            InitializeComponent();
        }

        private void UserProfileForm_Load(object sender, EventArgs e)
        {
            
            SqlConnection connection = new SqlConnection(conn);
            
            connection.Open();

            string query = @"SELECT Full_Name, Email_Address, Phone_Number
                         FROM UserAccount
                         WHERE User_ID = @UserID";

                SqlCommand cmd = new SqlCommand(query, connection);
            
                cmd.Parameters.AddWithValue("@UserID", userID);



            SqlDataReader reader = cmd.ExecuteReader();
                
                    if (reader.Read())
                    {
                        txtProfileName.Text = reader["Full_Name"].ToString();
                        txtProfilePhone.Text = reader["Phone_Number"].ToString();
                        txtProfileEmail.Text = reader["Email_Address"].ToString();
                    }
                
            


            connection.Close();
        }

        private void txtProfileName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.Image = Image.FromFile(openFileDialog.FileName);
                pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void btnVerification_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=localhost\SQLEXPRESS;
                                Initial Catalog=whatsinmycity;
                                Integrated Security=True;
                                TrustServerCertificate=True;";

            string documentNumber = txtDocNumber.Text;
            string documentType = comboBox1.Text;
            DateTime expiryDate = dtpDocExpiry.Value;

            if (string.IsNullOrWhiteSpace(documentNumber))
            {
                MessageBox.Show("Please enter your ID or Passport number.");
                return;
            }

            if (string.IsNullOrWhiteSpace(documentType))
            {
                MessageBox.Show("Please select a document type.");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"
            INSERT INTO Government_Document
            (
                User_ID,
                Passport_Copy,
                ID_Copy,
                Visa_Details,
                OCR_Verification_Status,
                Expiry_Date,
                Passport_Number,
                ID_Number
            )
            VALUES
            (
                @UserID,
                @PassportCopy,
                @IDCopy,
                @VisaDetails,
                @OCRStatus,
                @ExpiryDate,
                @PassportNumber,
                @IDNumber
            )";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", userID);

                    // basic setup for validity checks for use in further implementation of the system
                    // (THIS IS NOT DONE IN THIS PROJECT DUE TO SCOPE)
                    cmd.Parameters.AddWithValue("@PassportCopy", "VALID");
                    cmd.Parameters.AddWithValue("@IDCopy", "VALID");
                    cmd.Parameters.AddWithValue("@VisaDetails", "VALID");
                    cmd.Parameters.AddWithValue("@OCRStatus", "VALID");

                    // Expiry date of the document being submitted
                    cmd.Parameters.AddWithValue("@ExpiryDate", expiryDate);

                    // Checks for whether ID or passport is selected and then fulls in the relevant field
                    if (documentType == "ID Document")
                    {
                        cmd.Parameters.AddWithValue("@IDNumber", documentNumber);
                        cmd.Parameters.AddWithValue("@PassportNumber", DBNull.Value);
                    }
                    else if (documentType == "Passport")
                    {
                       

                        cmd.Parameters.AddWithValue("@PassportNumber", documentNumber);
                        cmd.Parameters.AddWithValue("@IDNumber", DBNull.Value);
                    }

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            lblOCRStatus.Visible = true;
            lblOCRMatch.Visible = true;

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have been logged out.");
            Application.Exit();
        }

        private void btnBackToMain_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
