﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace What_sInMyCity
{
    public partial class TravelPassForm : Form
    {
        public int userID = 1;
        public string conn = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=whatsinmycity;Integrated Security=True;TrustServerCertificate=True";
        public TravelPassForm()
        {
            InitializeComponent();
        }

        private void TravelPassForm_Load(object sender, EventArgs e)
        {


            using (SqlConnection connection = new SqlConnection(conn))
            {
                string query = @"
                SELECT
                tp.Travel_Pass_Id,
                tp.Pass_Type,
                tp.Expiry_Date,
                ua.Full_Name
                FROM Travel_Pass tp
                INNER JOIN UserAccount ua
                ON tp.User_ID = ua.User_ID
                WHERE tp.User_ID = @UserID";

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@UserID", userID);

                connection.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    lblPassIdD.Text = reader["Travel_Pass_Id"].ToString();
                    lblPassTypeD.Text = reader["Pass_Type"].ToString();
                    lblPassHolderN.Text = reader["Full_Name"].ToString();
                    lblPassValidD.Text = Convert.ToDateTime(reader["Expiry_Date"])
                                            .ToString("dd/MM/yyyy");


                    lblPassStatusD.Text = "Valid";
                }

                reader.Close();
            }
        }
    }
}
